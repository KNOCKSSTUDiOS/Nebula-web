# KNOCKSSTUDiOS — Brand Tokens

BRAND_BG = #1B1B1E (Astro Noir)
MATERIAL_STYLE = high-gloss-o-ring

## Hierarchy
KNOCKSSTUDiOS™
├── Hollywood Imaging Studio™ (MAIN)
│     ├── SOUL-QUANTUM-44 Studio™
│     ├── NEBULA Quantum-44 Studio™
│     └── NEBULA Multiverse Platform™
