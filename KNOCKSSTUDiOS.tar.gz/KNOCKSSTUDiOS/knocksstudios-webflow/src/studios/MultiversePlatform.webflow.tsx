// MultiversePlatform.webflow.tsx — Webflow binding
export { default } from "./MultiversePlatform";
