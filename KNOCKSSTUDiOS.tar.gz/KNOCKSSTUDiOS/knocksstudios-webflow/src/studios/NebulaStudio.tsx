// NebulaStudio.tsx — KNOCKSSTUDiOS
export default function NebulaStudio() {
  return null;
}
