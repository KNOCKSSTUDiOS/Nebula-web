// SoulStudio.tsx — KNOCKSSTUDiOS
export default function SoulStudio() {
  return null;
}
