// MultiversePlatform.tsx — KNOCKSSTUDiOS
export default function MultiversePlatform() {
  return null;
}
